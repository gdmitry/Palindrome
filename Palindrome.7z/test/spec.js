'use strict';

require('./spec/palindrome.js');