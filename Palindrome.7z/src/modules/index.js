'use strict';

require('./form.js');